A zip file for testing purposes.
